<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage ESGI_Custom
 * @since Twenty Twenty-One 1.0
 */

the_title( '<h1 class="entry-title">', '</h1>' );
